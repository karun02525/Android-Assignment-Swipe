package com.swipeapp.ui


import android.view.View
import android.view.ViewGroup
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.Espresso.pressBack
import androidx.test.espresso.action.ViewActions.*
import androidx.test.espresso.assertion.ViewAssertions.*
import androidx.test.espresso.matcher.ViewMatchers.*
import androidx.test.ext.junit.rules.ActivityScenarioRule
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.filters.LargeTest
import com.swipeapp.R
import org.hamcrest.Description
import org.hamcrest.Matcher
import org.hamcrest.Matchers.allOf
import org.hamcrest.Matchers.`is`
import org.hamcrest.TypeSafeMatcher
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith

@LargeTest
@RunWith(AndroidJUnit4::class)
class ProductActivityTest2 {

    @Rule
    @JvmField
    var mActivityScenarioRule = ActivityScenarioRule(ProductActivity::class.java)

    @Test
    fun productActivityTest2() {
        val searchAutoComplete = onView(
            allOf(
                withId(androidx.appcompat.R.id.search_src_text),
                childAtPosition(
                    allOf(
                        withId(androidx.appcompat.R.id.search_plate),
                        childAtPosition(
                            withId(androidx.appcompat.R.id.search_edit_frame),
                            1
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        searchAutoComplete.perform(replaceText("chingari"), closeSoftKeyboard())

        val appCompatImageView = onView(
            allOf(
                withId(androidx.appcompat.R.id.search_close_btn),
                withContentDescription("Clear query"),
                childAtPosition(
                    allOf(
                        withId(androidx.appcompat.R.id.search_plate),
                        childAtPosition(
                            withId(androidx.appcompat.R.id.search_edit_frame),
                            1
                        )
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        appCompatImageView.perform(click())

        val searchAutoComplete2 = onView(
            allOf(
                withId(androidx.appcompat.R.id.search_src_text),
                childAtPosition(
                    allOf(
                        withId(androidx.appcompat.R.id.search_plate),
                        childAtPosition(
                            withId(androidx.appcompat.R.id.search_edit_frame),
                            1
                        )
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        searchAutoComplete2.perform(replaceText(""), closeSoftKeyboard())

        val floatingActionButton = onView(
            allOf(
                withId(R.id.fb_button),
                childAtPosition(
                    childAtPosition(
                        withClassName(`is`("android.widget.FrameLayout")),
                        0
                    ),
                    2
                ),
                isDisplayed()
            )
        )
        floatingActionButton.perform(click())

        val appCompatImageView2 = onView(
            allOf(
                withId(R.id.choose_image),
                childAtPosition(
                    childAtPosition(
                        withClassName(`is`("android.widget.FrameLayout")),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        appCompatImageView2.perform(click())

        val linearLayout = onView(
            allOf(
                withId(com.github.dhaval2404.imagepicker.R.id.lytGalleryPick),
                childAtPosition(
                    childAtPosition(
                        withId(androidx.appcompat.R.id.custom),
                        0
                    ),
                    1
                ),
                isDisplayed()
            )
        )
        linearLayout.perform(click())

        val actionMenuItemView = onView(
            allOf(
                withId(com.github.dhaval2404.imagepicker.R.id.menu_crop),
                withContentDescription("Crop"),
                childAtPosition(
                    childAtPosition(
                        withId(com.github.dhaval2404.imagepicker.R.id.toolbar),
                        2
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        actionMenuItemView.perform(longClick())

        val actionMenuItemView2 = onView(
            allOf(
                withId(com.github.dhaval2404.imagepicker.R.id.menu_crop),
                withContentDescription("Crop"),
                childAtPosition(
                    childAtPosition(
                        withId(com.github.dhaval2404.imagepicker.R.id.toolbar),
                        2
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        actionMenuItemView2.perform(click())

        val textInputEditText = onView(
            allOf(
                withId(R.id.item_name),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.item_name_label),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText.perform(replaceText("Chingari logo"), closeSoftKeyboard())

        val textInputEditText2 = onView(
            allOf(
                withId(R.id.item_name), withText("Chingari logo"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.item_name_label),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText2.perform(pressImeActionButton())

        val textInputEditText3 = onView(
            allOf(
                withId(R.id.item_type),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.item_type_label),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText3.perform(replaceText("Tech4Billopn"), closeSoftKeyboard())

        val textInputEditText4 = onView(
            allOf(
                withId(R.id.item_type), withText("Tech4Billopn"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.item_type_label),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText4.perform(pressImeActionButton())

        val textInputEditText5 = onView(
            allOf(
                withId(R.id.item_price),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.item_price_label),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText5.perform(replaceText("12000"), closeSoftKeyboard())

        val textInputEditText6 = onView(
            allOf(
                withId(R.id.item_price), withText("12000"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.item_price_label),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText6.perform(pressImeActionButton())

        val textInputEditText7 = onView(
            allOf(
                withId(R.id.item_tax),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.item_tax_label),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText7.perform(replaceText("20"), closeSoftKeyboard())

        val textInputEditText8 = onView(
            allOf(
                withId(R.id.item_tax), withText("20"),
                childAtPosition(
                    childAtPosition(
                        withId(R.id.item_tax_label),
                        0
                    ),
                    0
                ),
                isDisplayed()
            )
        )
        textInputEditText8.perform(pressImeActionButton())

        val materialButton = onView(
            allOf(
                withId(R.id.save_action), withText("Add Product"),
                childAtPosition(
                    childAtPosition(
                        withClassName(`is`("android.widget.FrameLayout")),
                        0
                    ),
                    5
                ),
                isDisplayed()
            )
        )
        materialButton.perform(click())
        pressBack()
    }

    private fun childAtPosition(
        parentMatcher: Matcher<View>, position: Int
    ): Matcher<View> {

        return object : TypeSafeMatcher<View>() {
            override fun describeTo(description: Description) {
                description.appendText("Child at position $position in parent ")
                parentMatcher.describeTo(description)
            }

            public override fun matchesSafely(view: View): Boolean {
                val parent = view.parent
                return parent is ViewGroup && parentMatcher.matches(parent)
                        && view == parent.getChildAt(position)
            }
        }
    }
}
