package com.swipeapp.ui.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.widget.SearchView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.viewModelScope
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import com.swipeapp.R
import com.swipeapp.databinding.FragmentProductListBinding
import com.swipeapp.domain.model.ProductModel
import com.swipeapp.network.ResponseStatus
import com.swipeapp.ui.ProductViewModel
import com.swipeapp.ui.adapter.ProductListAdapter
import com.swipeapp.utils.progressHideShow
import com.swipeapp.utils.toast
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject

class ProductListFragment : Fragment() {
    private lateinit var binding: FragmentProductListBinding
    private val viewModel: ProductViewModel by inject()
    private lateinit var mProductListAdapter: ProductListAdapter
    var suggestionList = mutableListOf<ProductModel>()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentProductListBinding.inflate(inflater, container, false)
        setupViewModel()
        navigate()
        callApi()
        return binding.root
    }

    private fun navigate() {
        binding.fbButton.setOnClickListener {
            findNavController().navigate(R.id.action_productListFragment_to_addProductFragment)
        }
    }

    private fun callApi() {
        viewModel.viewModelScope.launch {
            viewModel.getProduct()
        }
    }

    private fun setupViewModel() {
        lifecycleScope.launch {
            viewModel.productList.collectLatest {
                when (it) {
                    is ResponseStatus.Error -> {
                        activity?.toast(it.message ?: "")
                    }

                    is ResponseStatus.Loading -> {
                        binding.progressCircular.progressHideShow(it.loading)
                    }

                    is ResponseStatus.Success -> {
                        suggestionList = it.data as MutableList<ProductModel>
                        setUpUI()
                    }
                }
            }
        }
    }

    private fun setUpUI() {
        binding.rvProduct.layoutManager = LinearLayoutManager(activity)
        binding.rvProduct.setHasFixedSize(true)
        mProductListAdapter = ProductListAdapter(suggestionList)
        binding.rvProduct.adapter = mProductListAdapter

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterList(newText)
                return true
            }
        })
    }

    private fun filterList(query: String?) {
        if (query != null) {
            val filteredList = ArrayList<ProductModel>()
            for (i in suggestionList) {
                if (i.productName.lowercase().contains(query)) {
                    filteredList.add(i)
                }
            }
            if (filteredList.isEmpty()) {
                activity?.toast("No Data found")
            } else {
                if (::mProductListAdapter.isInitialized) {
                    mProductListAdapter.setFilteredList(filteredList)
                }
            }
        }
    }
}