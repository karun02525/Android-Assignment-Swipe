package com.swipeapp.ui.fragments

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.lifecycle.viewModelScope
import androidx.navigation.fragment.findNavController
import com.github.dhaval2404.imagepicker.ImagePicker
import com.swipeapp.databinding.FragmentAddProductBinding
import com.swipeapp.network.ResponseStatus
import com.swipeapp.ui.ProductViewModel
import com.swipeapp.utils.progressHideShow
import com.swipeapp.utils.toast
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject


class AddProductFragment : Fragment() {
    private val viewModel: ProductViewModel by inject()
    private var uri: Uri? = null
    private lateinit var binding: FragmentAddProductBinding

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        binding = FragmentAddProductBinding.inflate(inflater, container, false)
        setupViewModel()
        operation()
        return binding.root
    }


    private fun operation() {
        binding.saveAction.setOnClickListener {
            validation()
        }
        binding.chooseImage.setOnClickListener {
            chooseImage()
        }
    }


    private fun validation() {
        val name = binding.itemName.text.toString()
        val type = binding.itemType.text.toString()
        val price = binding.itemPrice.text.toString()
        val tax = binding.itemTax.text.toString()

        if (name.isEmpty()) {
            toast("Please enter product name")
        } else if (type.isEmpty()) {
            toast("Please enter product type")
        } else if (price.isEmpty()) {
            toast("Please enter product price")
        } else if (tax.isEmpty()) {
            toast("Please enter product tax")
        } else {
            viewModel.viewModelScope.launch {
                viewModel.addProduct(name, type, price, tax, uri)
            }
        }
    }

    private fun setupViewModel() {
        lifecycleScope.launch {
            viewLifecycleOwner.repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.addProduct.collectLatest {
                    when (it) {
                        is ResponseStatus.Error -> {
                            toast(it.message ?: "")
                        }
                        is ResponseStatus.Loading -> {
                            binding.progressCircular.progressHideShow(it.loading)
                        }
                        is ResponseStatus.Success -> {
                            it.message?.let { it1 -> toast(it1) }
                            findNavController().popBackStack()
                        }
                    }
                }
            }
        }
    }

    private fun chooseImage() {
        ImagePicker.with(this)
            .crop()
            .compress(1024)
            .maxResultSize(1080, 1080)
            .start()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (resultCode) {
            Activity.RESULT_OK -> {
                val uri: Uri = data?.data!!
                this.uri = uri
                binding.chooseImage.setImageURI(uri)
            }

            ImagePicker.RESULT_ERROR -> {
                toast(ImagePicker.getError(data))
            }

            else -> {
                toast("Task Cancelled")
            }
        }
    }
    private fun toast(mess:String){
        activity?.toast(mess)
    }
}
