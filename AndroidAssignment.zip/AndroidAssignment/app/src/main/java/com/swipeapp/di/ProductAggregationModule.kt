package com.swipeapp.di

val productModulesAggregation = listOf(
    productDomainModule,
    productDataMapperModule,
    productViewModelModule,
)